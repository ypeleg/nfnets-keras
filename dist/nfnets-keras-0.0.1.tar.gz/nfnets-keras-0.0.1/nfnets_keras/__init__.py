

from .sgd_agc import SGD_AGC
from .nfnet_layers import WSConv2D, StochasticDepth, SqueezeExcite
from .nfnet import NFBlock, NFNet, NFNetF0, NFNetF1, NFNetF2, NFNetF3, NFNetF4, NFNetF5, NFNetF6, NFNetF7

